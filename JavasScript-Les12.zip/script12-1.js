$(document).ready(function laden() {
  $('#divResult').load('https://mar-it.github.io/JavaLes12/content12.html');
});
